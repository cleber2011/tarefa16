//01 - pacote
package tarefa16;

//02 - bibliotecas


import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

//03 - classes

@RunWith(Parameterized.class)

public class tarefa16 {
    //3.1 - Atributos = Caracter�sticas
    static String url;
    WebDriver driver;
    String pastaPrint = "evidencias/" + new SimpleDateFormat("yyyy-MM-dd HH-mm").format(Calendar.getInstance().getTime()) + "/";

    //3.2 - m�todos ou fun��es
    //m�todos ou fun��es de apoio (util/commons)
    public void tirarPrint(String nomePrint) throws IOException {
        File foto = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(foto,new File(pastaPrint + nomePrint +".png"));
    }

    // Fun��o para ler uma massa de testes
    //3.3 - Atributos / Campos da Massa de testes
    private String id;
    private String pesquisa;
    private String titulo;
    private String categoria;
    private String browser;

    public tarefa16(String id, String pesquisa, String titulo, String categoria, String browser) {
        this.id = id;
        this.pesquisa = pesquisa;
        this.titulo = titulo;
        this.categoria = categoria;
        this.browser = browser;
    }

    @Parameterized.Parameters
    public static Collection<String[]> intermediarioCsv() throws IOException {
        return LerCSV("db/Tarefa 16 pesquisa google.csv");
    }

    public static Collection<String[]> LerCSV(String nomeCSV) throws IOException {
        BufferedReader arquivo = new BufferedReader(new FileReader(nomeCSV));
        String linhaCsv;
        List<String[]> dados = new ArrayList<>();

        while((linhaCsv = arquivo.readLine()) != null){
            String[] campos = linhaCsv.split(";");
            //dados.add(String.valueOf(campos));
            dados.add(campos);

        }
        arquivo.close();
        return dados;
    }


    @BeforeClass
    public static void antesDeTudo(){
        url = "https://www.google.com.br/"; // declarando o conte�do da String url
        // Liga��o do Webdriver Selenium com o Chrome (browser)
        System.setProperty("webdriver.chrome.driver","drivers/chrome/87/chromedriver.exe");
        System.setProperty("webdriver.edge.driver","drivers/edge/msedgedriver.exe");
        System.setProperty("webdriver.gecko.driver","drivers/firefox/geckodriver.exe");
    }



    //3.4 - M�todos e funcionalidades = O que vai fazer (m�todo executa sem retorno)
    @Before
    public void iniciar() {
        switch(browser){
            case "Chrome":
                driver = new ChromeDriver();//Instanciar o objeto Selenium WebDriver
                break;
            case "Firefox":
                driver = new FirefoxDriver();
                break;
            case "Edge":
                driver = new EdgeDriver();
                break;
        }
        driver.manage().window().maximize(); // maximiza a tela
        driver.manage().timeouts().implicitlyWait(3000, TimeUnit.MILLISECONDS);

    }

    @After
    public void finalizar (){
        //driver.quit(); // finalizar(destroi) o objeto Selenium Webdriver
    }

    @Test
    public void consultarGoogle () throws IOException, InterruptedException {
        driver.get(url);
        tirarPrint("01 - Acesso ao site do Google Brasil");
        driver.findElement(By.name("q")).sendKeys(Keys.chord(pesquisa) + Keys.ENTER);
        Thread.sleep(2000);
        tirarPrint("02 - Resultado da pesquisa");
        driver.findElement(By.cssSelector("h3.LC20lb.DKV0Md")).click();
        Thread.sleep(2000);
        tirarPrint("03 - Site com a not�cia");
        assertEquals(titulo,driver.findElement(By.cssSelector("h1.content-head__title")).getText());
        assertEquals(categoria,driver.findElement(By.cssSelector("a.header-editoria--link.ellip-line")).getText());

    }




}
